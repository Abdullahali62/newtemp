require("./lib/module")

// SETTING KONTAK
global.owner = "6288803536269"
global.ownername = "☠︎︎༒︎~𝐃𝐚𝐧𝐳𝐳𝐓𝐳𝐲༒︎☠︎"
global.nomorbot = "6285746858365"
global.namaCreator = "☠︎︎༒︎~𝐃𝐚𝐧𝐳𝐳𝐓𝐳𝐲༒︎☠︎"
global.Dec = "𝐌𝐮𝐥𝐭𝐢 𝐃𝐞𝐯𝐢𝐜𝐞"
global.autoJoin = false
global.antilink = false

// THUMBNAIL (BEBAS GANTI)
global.imageurl = 'https://pomf2.lain.la/f/ui91utqk.jpg'
global.channel = 'https://whatsapp.com/channel/0029VagBKMhEwEjyKtGV8y3H'

// STICKER
global.packname = "𝐌𝐮𝐥𝐭𝐢 𝐃𝐞𝐯𝐢𝐜𝐞 𝙑2"
global.author = "꧁•༆𝐃𝐚𝐧𝐳𝐳𝐓𝐳𝐲🚹࿇꧂"
global.jumlah = "5"


















// RESPON BOT
global.onlyprem = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_𝘊𝘰𝘮𝘮𝘢𝘯𝘥 for prem users or ☠︎︎༒︎~𝑇𝛥𝛫𝛥༒︎☠︎ members and you're not 😑_*`
global.onlyown = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 is only for my 𝘰𝘸𝘯𝘦𝘳 👀*`
global.onlygroup = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_𝘊𝘰𝘮𝘮𝘢𝘯𝘥 is only for groups 😑_*`
global.onlyadmin = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_𝘊𝘰𝘮𝘮𝘢𝘯𝘥 is only for admin 🥱_*`
global.notext = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_Where's the text? 🧐_*`
global.noadmin = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_𝘉𝘰𝘵 is not admin need it first 🥺_*`
global.succes = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_𝘋𝘰𝘯𝘦 executing command 😁_*`
global.invalid = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*𝘔𝘢𝘴𝘶𝘬𝘬𝘢𝘯 𝘯𝘰𝘮𝘰𝘳 𝘺𝘢𝘯𝘨 𝘷𝘢𝘭𝘪𝘥*`
global.bugrespon = `\`[ # ] ༒☬𝙏𝘼𝙆𝘼 𝘽𝙐𝙂 𝙑2☬༒\` \n*_Successfully sending bugq to victim confirmation 🙂✅_*`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})