global.owner = [
  "6285166447364", //ganti nomor owner
  "6285640158496" //nomor owner kedua kalo ada
]
global.nomorbot = '62xxx'
global.urlfoto = 'https://'

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})


//BUY NO ENC PM LANGITDEV AJA!! 